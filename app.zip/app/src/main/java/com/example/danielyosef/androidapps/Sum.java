package com.example.danielyosef.androidapps;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Sum extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sum);
        String title = "Two Numbers Sum";
        setTitle(title);

        Intent intent = getIntent();
        int first = intent.getIntExtra("FIRST_NUMBER", 0);
        int sec = intent.getIntExtra("SEC_NUMBER", 0);
        TextView textView = (TextView)findViewById(R.id.button);
        textView.setText("sum is = " + (first+sec));
    }
}